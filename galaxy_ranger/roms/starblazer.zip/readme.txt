Sega's Star Blazer. 1983
uses many roms from Astron Belt and Galaxy Ranger, also by Sega

Main PCB 834-5174
Sega cpus 315-5012, 315-5011
NEC D780C

Sound PCB 834-5315

OSC: 20.000 Mhz

DIPS: 2 x 8 position

